#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

REQ1=$(which gnome-terminal)
req1="$REQ1"

clear

if [ $req1 = "/usr/bin/gnome-terminal" ]
then
	echo "REQ1=true"
	clear
else
	echo "REQ1=false"
	clear
	sudo apt-get -y install gnome-terminal
	clear
fi

clear

read -p "[RabbitHole] Retrieve by Username (johndoe, janedoe, etc..): " RNAME

clear

cd /home/$USERNAME/Desktop && clear && echo "Retrieving RabbitHole User File.." && wget --no-clobber --no-check-certificate --no-cache --no-glob --accept="pdf,PDF" --quiet "https://github.com/alectramell/rabbithole/raw/master/$RNAME.pdf"

clear

sensible-browser /home/$USERNAME/Desktop/$RNAME.pdf

clear
