#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

REQ1=$(which zenity)
req1="$REQ1"
REQ2=$(which nautilus)
req2="$REQ2"

if [ $req1 = "/usr/bin/zenity" ]
then
	echo "REQ1=true"
else
	echo "REQ1=false"
	sudo apt-get -y install zenity
	clear
fi

if [ $req2 = "/usr/bin/nautilus" ]
then
	echo "REQ2=true"
else
	echo "REQ2=false"
	sudo apt-get -y install nautilus
	clear
fi

clear

xdownload() {

FILENAME=$(zenity --entry --title="RabbitHole v1.0" --text="Package Name (example.. google-search):" --ok-label="Download")

clear
mkdir /home/$USERNAME/rabbithole
clear
wget --no-check-certificate -O /home/$USERNAME/rabbithole/$FILENAME-1.0.deb -c https://github.com/alectramell/rabbithole/raw/master/$FILENAME-1.0.deb

nautilus /home/$USERNAME/rabbithole/$FILENAME-1.0.deb

notify-send --urgency="critical" --icon="/usr/share/rabbithole/rhole.svg" "RabbitHole.." "PKG Download Complete!"

}

clear

xinstall() {

FILENAME=$(zenity --entry --title="RabbitHole v1.0" --text="Package Name (example.. google-search):" --ok-label="Install")

clear
mkdir /home/$USERNAME/rabbithole
clear
wget --no-check-certificate -O /home/$USERNAME/rabbithole/$FILENAME-1.0.deb -c https://github.com/alectramell/rabbithole/raw/master/$FILENAME-1.0.deb

notify-send --urgency="critical" --icon="/usr/share/rabbithole/rhole.svg" "RabbitHole.." "PKG Download Complete!"

gnome-terminal --title="RabbitHole v1.0 | PKG Install.." -x sh -c "sudo dpkg -i /home/$USERNAME/rabbithole/$FILENAME-1.0.deb"

nautilus /home/$USERNAME/rabbithole/$FILENAME-1.0.deb

}

clear

xclose() {

exit

}

clear

MCHOSE=$(zenity --list --title="RabbitHole v1.0" --text="Install, or Simply Download?.." --column="options" --imagelist "/usr/share/rabbithole/id.png" "/usr/share/rabbithole/dd.png" --hide-header --width="220" --height="228")

mchose="$MCHOSE"

clear

if [ $mchose = "/usr/share/rabbithole/id.png" ]
then
	xinstall

elif [ $mchose = "/usr/share/rabbithole/dd.png" ]
then
	xdownload
else
	xclose
fi

clear
