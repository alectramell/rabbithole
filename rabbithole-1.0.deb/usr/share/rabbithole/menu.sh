#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

REQ1=$(which gnome-terminal)
req1="$REQ1"

clear

if [ $req1 = "/usr/bin/gnome-terminal" ]
then
	echo "REQ1=true"
	clear
else
	echo "REQ1=false"
	clear
	sudo apt-get -y install gnome-terminal
	clear
fi

clear

read -p "[RabbitHole] Retrieve resume by Username (johndoe, janedoe, etc..): " RNAME

clear

if [ "$RNAME" = "exit" ]
then
	echo "Exiting.."
	sleep 1
	clear
	exit
else
	cd /home/$USERNAME/Desktop
	clear
	echo "Retrieving RabbitHole User File.."
	wget --no-clobber --no-check-certificate --no-cache --no-glob --accept="pdf,PDF" --quiet --directory-prefix="/home/$USERNAME/Desktop" "https://github.com/alectramell/rabbithole/raw/master/$RNAME.pdf"

fi

clear

sensible-browser /home/$USERNAME/Desktop/$RNAME.pdf

clear
