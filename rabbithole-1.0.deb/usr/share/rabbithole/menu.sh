#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

download() {

echo "================="
echo " RabbitHole v1.0 "
echo "================="
read -p "Get Script Name: " FILENAME

clear

mkdir /home/$USERNAME/rabbithole
clear
wget --no-check-certificate -O /home/$USERNAME/rabbithole/$FILENAME.sh -c https://github.com/alectramell/rabbithole/raw/master/$FILENAME.sh

nautilus /home/$USERNAME/rabbithole/$FILENAME.sh

}

clear

download
