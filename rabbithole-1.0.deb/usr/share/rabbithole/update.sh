#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

REQ1=$(which notify-send)
req1="$REQ1"

clear

if [ $req1 = "/usr/bin/notify-send" ]
then
	echo "REQ1=true"
	clear
else
	echo "REQ1=false"
	clear
	sudo apt-get -y install notify-send
fi

clear

echo "[Updating New RabbitHole Package..]"

sleep 2.5

cd /home/$USERNAME/Desktop && wget --no-check-certificate --no-clobber --no-glob --accept="deb,DEB" --quiet https://github.com/alectramell/rabbithole/raw/master/rabbithole-1.0.deb

clear

echo "[Installing New RabbitHole Package..]"

sleep 2

sudo dpkg -i /home/$USERNAME/Desktop/rabbithole-1.0.deb

clear

notify-send --urgency="critical" --icon="/usr/share/rabbithole/rhole.svg" "RabbitHole" "Update Complete!"
